#ifndef _TRAFFIC_TYPE_H_
#define _TRAFFIC_TYPE_H_

#include <semaphore.h>

//路口数据宏定义
//static value
#define NUM_AREA                    64      //系统最大区域数
#define NUM_SUBAREA                 16      //区域最大子区数
#define NUM_JUNCTION                256     //区域最大路口数
#define NUM_SUBJUNC                 32      //子区最大路口数
#define NUM_ORNT                    4       //路口一般方向数
#define NUM_MAXORNT                 8       //路口最大方向数
#define NUM_VEHROAD                 32      //路口最大机动车车道数
#define NUM_BIKEROAD                8       //路口最大自行车车道数
#define NUM_DIRROAD                 8       //方向最大车道数
#define NUM_ROAD                    (NUM_VEHROAD+NUM_BIKEROAD)      //路口最大车道数
#define NUM_PLAN                    16      //配时方案数
#define NUM_STAGE                   16      //路口最大相位数
#define NUM_VEHDET                  32      //路口最大机动车检测器数
#define NUM_BIKEDET                 8       //路口最大自行车检测器数
#define NUM_DETECTOR                (NUM_VEHDET+NUM_BIKEDET)        //一个路口最大检测器数
#define NUM_CHILDJUNC               4

//车道方向编码
#define RD_NORTH                    0   //北方向
#define RD_EAST                     1   //东方向
#define RD_SOUTH                    2   //南方向
#define RD_WEST                     3   //西方向
#define RD_EAST_NORTH               4   //东北方向
#define RD_EAST_SOUTH               5   //东南方向
#define RD_WEST_SOUTH               6   //西南方向
#define RD_WEST_NORTH               7   //西北方向

#define RD_ORNT_TOTAL                8   //每个基准路口最多8个进(出)口

//车道类型编码
#define RC_LEFT_RIGHT_STRAIGHT      0    //左直右车道
#define RC_LEFT_RIGHT               1    //左右车道
#define RC_LEFT_STRAIGHT            2    //左直车道
#define RC_RIGHT_STRAIGHT            3    //右直车道
#define RC_STRAIGHT                 4    //直行车道
#define RC_RIGHT                    5    //右转车道
#define RC_LEFT                     6    //左转车道
#define RC_BIKE                     7    //自行车道
#define RC_ZEBRA                    8    //人行横道
#define RC_OUT                      9    //出口车道

#define NUM_LANE_PER_ORNT           5    //每个方向最大车道数量

#define NUM_STAGE                   16   //路口最大相位数

#define MAX_LEN_STAGE_NAME          40

#define MAX_JUNC_NAME_LEN           64
#define MAX_JUNC_IMEI_LEN           16

#define TRAFFIC_GEOHASH_LEN         24   //GEOHASH最大存储长度，包含结尾\0
#define CITYNO_MAX_LEN              8    //城市号字符串长度，包含结尾的\0

#define DIR_TURN_BIT                0
#define DIR_LEFT_BIT                1
#define DIR_STRAIGHT_BIT            2
#define DIR_RIGHT_BIT               3
#define NUM_DIR                     4

#define NUM_MAX_TC                  50  //每次灯色变换都有报文，如果存储历史，需要关注是否超界

#define CONSTANT_COLOR_FLAG         0x7FFF
//---------------------------------------------------------------------------------
typedef enum
{
    F_NO_CONTROLLER = 0,    //无工作信号机，包括未安装信号机和其它厂家信号机
    F_JUNC_PB       = 1,    //安装路口探针
    F_AREA_PB       = 2,    //区域探针控制，本身无探针
    F_JUNC_AREA_PB  = 3     //区域探针控制，且安装探针（南通）
} E_PROBE_BITMASK_FLAG;

typedef enum
{
    DOT_OFF = 0,
    DOT_GREEN = 1
} E_DOT_TYPE;

typedef enum
{
    JUNC_LES_LINK = 1,
    JUNC_LES_UNLINK = 2,
    JUNC_NO_ANNUNCIATOR = 3,
    JUNC_PSEUDO = 4,
    JUNC_OTHER_MAN = 5
} E_JUNC_TYPE;

//路口编码
typedef struct
{
    Char cityno[CITYNO_MAX_LEN];              //城市号，最大长度为8，最后一位为\0
    Int areano;
    Int juncno;
} S_JUNC_CODE;

//路口基本属性
typedef struct
{
    BOOL used;                                //0: FALSE; 1: TRUE
    Int category;                             //category: 1: 莱斯信号机, 2: 有莱斯信号机但未联网，3: 无信号机, 4: 伪路口, 5:其他厂家信号机；
//    E_PROBE_FLAG flag;
    S_JUNC_CODE code;                         //路口编码，包含city,area,juncno,juncno在area范围内唯一
    Char geoHashCode[TRAFFIC_GEOHASH_LEN];    //HASH字符串
    Double lat;                               //纬度
    Double lon;                               //经度
    Char name[MAX_JUNC_NAME_LEN];
    Int map[NUM_ORNT];
    Int dot[NUM_ORNT];
} S_JUNC_BASE_INFO;

typedef struct
{
    Int nextJuncId;                          //路口编码，包含city,area,juncno,juncno在area范围内唯一
    Int ornt;                                //该路口相对于基准路口的方向：北、东、南、西
    Double degree;                           //以基准路口为基点从正北方向到该路口的角度
    Double distance;                         //从基准路口到该路口的距离，单位：米
    Float speed;                             //从基准路口驶向该路口的车速，单位：千米?秒
} S_JUNC_NEXT_NODE;

//路网属性
typedef struct
{
    Int numVicinJunc;                        //相邻路口数量
    S_JUNC_NEXT_NODE vicinJunc[NUM_MAXORNT]; //下标为相邻路口序号
} S_JUNC_NET_INFO;

//路口运行数据
typedef struct
{
    sem_t iosem;
    BOOL used;
    BYTE oldMode;
    BYTE nowMode;
    BYTE pad1;
    BYTE pad2;
    BYTE color[NUM_ORNT];
    Int timesettings[NUM_ORNT][NUM_DIR];
    Int alertTs;
    Int alertType;
    Int updateTs;
} S_JUNC_RUN_INFO;

typedef struct
{
    sem_t iosem;
    BOOL used;
    Int probeType;
    Int alertTs;                      //普通探针字段
    Int alertType;
    Int updateTs;
    Char imei[MAX_JUNC_IMEI_LEN];     
    Int alertTs2;                     //区域探针字段
    Int alertType2;
    Int updateTs2;
    Char imei2[MAX_JUNC_IMEI_LEN];    
} S_JUNC_ALERT_INFO;

typedef struct
{
    BYTE used;
    BYTE sn;
    BYTE yf;
    BYTE rf;
    BYTE color[NUM_ORNT];
    Int timesettings[NUM_ORNT][NUM_DIR];
} S_JUNC_STAGE_HIS_ITEM;

typedef struct
{
    Int num;
    Int pos;
    time_t updateTime;
    BOOL used;
    S_JUNC_STAGE_HIS_ITEM item[NUM_MAX_TC];
} S_JUNC_STAGE_HIS;

typedef struct
{
    struct RoadNodeInfo
    {
        Int nextJuncId;
        Int numLane;
        struct LaneInfo
        {
            Int laneCode;
            Int iden;                   //车道类型编码
            Char nameRoad[40];
        } laneInfo[NUM_LANE_PER_ORNT];
    } roadNodeInfo[NUM_MAXORNT];
} S_JUNC_ROAD_INFO;
#endif /* _TRAFFIC_TYPE_H_ */
