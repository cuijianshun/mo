#ifndef _BASE_TYPE_H_
#define _BASE_TYPE_H_


#define __DEBUG__
#ifdef __DEBUG__
    #define DEBUG(format,...) printf("File: "__FILE__", Line: %d: "format"\n", __LINE__, ##__VA_ARGS__)
#else
    #define DEBUG(format,...)
#endif

#define TRUE  1
#define FALSE 0

#define USER_ID_LEN 30 

#define TEST_CARKIT 0
#define TEST_TIMECOLOR_DELAY 0

#define MAX_HOST_NAME_LEN 256


typedef unsigned char BYTE;
typedef char          Char;
typedef short         WORD;
typedef int           Int;
typedef unsigned int  UInt;
typedef float         Float;
typedef double        Double;
typedef long          DWORD;
typedef int           BOOL;

typedef enum
{
    RC_TLC_OK = 0,
    RC_TLC_MQTT_ERR = -1,      // This is not an error
    RC_TLC_DATA_ERR = -2,
    RC_TLC_LINK_ABNORMAL = -3,
    RC_TLC_PARAM_ERR = -4,
    RC_TLC_MALLOC_ERR = -5,
    RC_TLC_MYSQL_ERR = -6,
    RC_TLC_LES_DISCONNECT = -7,
    RC_TLC_RADIO_MOS_ERR = -8,
    RC_TLC_TLB_MOS_ERR = -9,
    RC_TLC_TLB_DISCONNECT = -10,
    RC_TLC_THREAD_ERR = -11,
    RC_TLC_CONN_ERR = -12,
    RC_TLC_DATA_DUP = -13 
} E_TLC_RC;

#endif /*_BASE_TYPE_H_ */
