#ifndef _TLC_VERSION_H_
#define _TLC_VERSION_H_

/**
 *  Developer version: DXX.XX.XX
 *  Release version:   RXX.XX.XX
 */
#define VERSION "D01.01.00"

#endif /* _TLC_VERSION_H_ */
