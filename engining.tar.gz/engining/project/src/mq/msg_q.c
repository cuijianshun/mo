#include <stdlib.h>
#include <stdio.h>
#include <semaphore.h>
#include <sys/time.h>

#include "base_type.h"
#include "log.h"
#include "msg_q.h"

Int InitMsgQueue(S_MSG_Q* Q, Int size, BOOL inSemOp, BOOL outSemOp, Char *pName)
{
    if(!Q)
    {
        DEBUG("Invalid Queue!");
        LogWrite(ERROR, "%s", "Input param is invalid");
        return RC_TLC_PARAM_ERR;
    }

    Q->f_insem = inSemOp;
    Q->f_outsem = outSemOp;

    if(size >0 && size < MAX_QUEUE_SIZE)
    {
        Q->size = size;
    }
    else
    {
        Q->size = MAX_QUEUE_SIZE;
    }

    snprintf(Q->name, MQ_NAME_LEN, (pName == NULL)?"NONAME":pName);

    Q->rear = 0;
    Q->head = 0;
    sem_init(&Q->notisem, 0, 0);
    sem_init(&Q->insem, 0, 1);
    sem_init(&Q->outsem, 0, 1);
    Q->incount = 0;
    Q->outcount = 0;
    Q->used = TRUE;
    return RC_TLC_OK;
}

Int DeQueueMsg(S_MSG_Q* Q, S_MSG* msg)
{
    if(!Q)
    {
        DEBUG("Invalid Queue!");
        LogWrite(ERROR, "%s", "Input param is invalid");
        return RC_TLC_PARAM_ERR;
    }

    if(!msg)
    {
        LogWrite(ERROR, "%s", "Input param is invalid");
        return RC_TLC_PARAM_ERR;
    }

    while(TRUE)
    {
        if(0 == sem_wait(&Q->notisem))
        {
            break;
        }
        else
        {
            DEBUG("Queue %s sem_wait(&Q->notisem) return -1", Q->name);
            perror("sem_wait(&Q->notisem)");
        }
    }

    if(Q->f_outsem)
    {
        while(TRUE)
        {
            if(0 == sem_wait(&Q->outsem))
            {
                break;
            }
            else
            {
                DEBUG("Queue %s sem_wait(&Q->outsem) return -1", Q->name);
                perror("sem_wait(&Q->outsem)");
            }
        }
    }

    if(Q->rear == Q->head)
    {
        DEBUG("Empty Queue!");
        if(Q->f_outsem)
        {
            sem_post(&Q->outsem);
        }
        return RC_TLC_DATA_ERR;
    }

    memcpy(msg, &(Q->data[Q->head]), sizeof(S_MSG));
    Q->head = (Q->head+1)%Q->size;
    if(Q->f_outsem)
    {
        sem_post(&Q->outsem);
    }
    Q->outcount++;

    return RC_TLC_OK;
}

Int EnQueueMsg(S_MSG_Q* Q, S_MSG* msg)
{
    Char loginfo[MAXLEN];

    if(!Q)
    {
        DEBUG("Invalid Queue!");
        LogWrite(ERROR, "%s", "Input param is invalid");
        return RC_TLC_PARAM_ERR;
    }

    if(!msg)
    {
        LogWrite(ERROR, "%s", "Input param is invalid");
        return RC_TLC_PARAM_ERR;
    }

    if(!Q->used)
    {
        return RC_TLC_PARAM_ERR;
    }

    if(Q->f_insem)
    {
        while(TRUE)
        {
            if(0 == sem_wait(&Q->insem))
            {
                break;
            }
            else
            {
                DEBUG("Queue %s sem_wait(&Q->insem) return -1", Q->name);
                perror("sem_wait(&Q->insem)");
            }
        }
    }

    if(Q->head == (Q->rear+1)%Q->size)
    {
        DEBUG("Queue %s is full", Q->name);
        snprintf(loginfo, MAXLEN, "Queue %s is full!", Q->name);
        LogWrite(ERROR, "%s", loginfo);
        if(Q->f_insem)
        {
            sem_post(&Q->insem);
        }
        return RC_TLC_DATA_ERR;
    }
    else
    {
        memcpy(&(Q->data[Q->rear]), msg, sizeof(S_MSG));
        Q->rear = (Q->rear+1)%Q->size;

        sem_post(&Q->notisem);
        if(Q->f_insem)
        {
            sem_post(&Q->insem);
        }
        Q->incount++;
    }

    return RC_TLC_OK;
}
