#ifndef _ENG_MSG_QUEUE_H_
#define _ENG_MSG_QUEUE_H_

#include<semaphore.h>
#include <netinet/in.h>

#define RECV_MSG_BUF_LEN 1024
#define MSG_BODY_LEN 1024
#define MQ_NAME_LEN 20
#define MAX_QUEUE_SIZE 200
#define MOS_TOPIC_NAM_MAX_LEN 30
#define MOS_MSSAGE_MAX_LEN 3000

typedef enum
{
    MSG_ID_AREA_PROBE    = 1,
    MSG_ID_PROBE_2G_MQTT = 2,
    MSG_ID_PROBE_2G_UDP  = 3,
    MSG_ID_PROBE_4G      = 4,
    MSG_ID_PROBE_MANAGER = 5,
    MSG_ID_USER_SERVICE  = 6
} E_MSG_SRC_ID;

typedef struct
{
    Int msg_id;
    Int msg_type;
    Int msg_len;
    Int msg_stamp;
    BYTE data[MSG_BODY_LEN];
} S_MSG;

typedef struct
{
    BOOL used;
    Int head;
    Int rear;
    Int size;
    Int incount;
    Int outcount;
    sem_t notisem;
    sem_t insem;
    sem_t outsem;
    BOOL f_insem;
    BOOL f_outsem;
    Char name[MQ_NAME_LEN];
    S_MSG data[MAX_QUEUE_SIZE];
} S_MSG_Q;

extern int InitMsgQueue(S_MSG_Q* Q, Int size, BOOL inSemOp, BOOL outSemOp, Char *pName);
extern int DeQueueMsg(S_MSG_Q* Q, S_MSG* msg);
extern int EnQueueMsg(S_MSG_Q* Q, S_MSG* msg);
#endif /* _ENG_MSG_QUEUE_H_ */
