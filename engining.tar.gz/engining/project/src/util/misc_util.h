#ifndef _MISC_UTIL_H_
#define _MISC_UTIL_H_

#include "base_type.h"

#define MAX_CITYNO_LEN 8
#define MAX_PATH_LEN 1024

extern char gSelfFullPath[MAX_PATH_LEN];
extern char gCityNo[MAX_CITYNO_LEN];
extern Int gCityInt;

extern void SleepMilliseconds(unsigned long mSec);
extern Int GetSelfFullPath();
extern Int GetCityNo();
#endif /* _MISC_UTIL_H_ */
