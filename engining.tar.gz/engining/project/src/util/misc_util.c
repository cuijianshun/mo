#include <stdlib.h>
#include <sys/time.h>
#include <errno.h>
#include <unistd.h>

#include "base_type.h"
#include "baseconfig.h"
#include "misc_util.h"

#define MAX_CITYNO_LEN 8
#define MAX_PATH_LEN 1024

const char MODULE_CITY[MAX_MODULE_NAME] = "city";
const char KEY_AREACODE[MAX_KEY_NAME] = "areacode";

char gSelfFullPath[MAX_PATH_LEN] = {0};
char gCityNo[MAX_CITYNO_LEN] = {0};
Int gCityInt = 0;

void SleepMilliseconds(unsigned long mSec)
{
    Int err;
    struct timeval tv;
    tv.tv_sec = mSec/1000;
    tv.tv_usec = (mSec%1000)*1000;
    
    do {
       err = select(0,NULL,NULL,NULL,&tv);
    } while((err < 0) && (errno == EINTR));
}

Int GetSelfFullPath()
{
    Int cnt;
    Int i;

    cnt = readlink("/proc/self/exe", gSelfFullPath, 1024);

    if((cnt < 0) || (cnt > 1024))
    {
        return -1;
    }

    for(i = cnt; i >= 0; i--)
    {
        if(gSelfFullPath[i] == '/')
        {
            gSelfFullPath[i + 1] = '\0';
            break;
        }
    }
    return i;
}

Int GetCityNo()
{
    Int rc;

    if(0 != GetProfileString(SYS_CONF_FILE, MODULE_CITY, KEY_AREACODE, gCityNo))
    {
        gCityNo[0] = '#';
        gCityNo[1] = '\0';
        gCityInt = 0;
        rc = -1;
    }
    else
    {
        gCityInt = atoi(gCityNo);

        if(gCityInt < 100)
        {
            gCityInt = gCityInt * 10;
        }
        rc = 0;
    }

    return rc;
}
