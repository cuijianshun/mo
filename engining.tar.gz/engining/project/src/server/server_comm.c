#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <sys/time.h>
#include <semaphore.h>
#include <sys/epoll.h>
#include <errno.h>
#include <mosquitto.h>

#include "base_type.h"
#include "log.h"
#include "serverconfig.h"
#include "server_comm.h"
#include "msg_q.h"
#include "mqtt_comm.h"

#define MAXEPOLLSIZE 10000
#define MAX_CONN_REQ_HANDLE 20

#define ID_CLIENT_MSG    1
#define ID_SERVER_MSG    2
#define DEFAULT_LESSTAT_PORT 7001

#define CLIENTTOPIC   "dicheng"

const Char *MODULE_LESSTAT = "les station";
const Char *MODULE_SERVERSTAT = "server station";
//const Char *MODULE_CLIENTSTAT = "client station";

S_SERVER_CONF *p_gLesStatConf = NULL;   /* the net info of les station */
S_SERVER_CONF *p_gServerConf = NULL;   /* the net info of server station */
//S_SERVER_CONF *p_gClientConf = NULL;   /* the net info of client station */

const Char HEARTBEAT[10] = "{\"a\": 1}";

//Char gLastMsgBuf[RECV_MSG_BUF_LEN];
Int gLastMsgBufLen;
Int tcpSock;

pthread_t g_serverThread;
pthread_t tmpThreadId;
pthread_t g_clientThread;
pthread_t g_sendClientMsgQThread;


S_MSG_Q gSendClientMsgQ;
S_MSG_Q gSendServerMsgQ;



Int LoadLesStatConf()
{
    if(NULL != p_gLesStatConf)
    {
        return -1;
    }

    p_gLesStatConf = (S_SERVER_CONF *)malloc(sizeof(S_SERVER_CONF));

    if(NULL == p_gLesStatConf)
    {
        LogWrite(ERROR, "%s", "Malloc p_gLesStatConf failed");
        return -1;
    }

    LoadServerConf(MODULE_LESSTAT, p_gLesStatConf);

    if(p_gLesStatConf->host[0] == '\0')
    {
        LogWrite(ERROR, "%s", "No host info in configuration file.");
        return -1;
    }


    if(p_gLesStatConf->port == 0)
    {
        LogWrite(ERROR, "%s", "No port info in configuration file.");
        return -1;
    }

    return 0;
}

Int LoadDataServerConf()
{
    if(NULL != p_gServerConf)
    {
        return -1;
    }

    p_gServerConf = (S_SERVER_CONF *)malloc(sizeof(S_SERVER_CONF));

    if(NULL == p_gServerConf)
    {
        LogWrite(ERROR, "%s", "Malloc p_gServerConf failed");
        return -1;
    }

    LoadServerConf(MODULE_SERVERSTAT, p_gServerConf);

    if(p_gServerConf->host[0] == '\0')
    {
        LogWrite(ERROR, "%s", "No host info in configuration file.");
        return -1;
    }


    if(p_gServerConf->port == 0)
    {
        LogWrite(ERROR, "%s", "No port info in configuration file.");
        return -1;
    }

    return 0;
}

Int RecvMsgAfterSelected(Int server_sock_fd)
{  
    BYTE recv_msg[RECV_MSG_BUF_LEN];
    //BYTE* handleMsgBuf = NULL;
    //Int handleMsgLen;
    Int recv_len;
    S_MSG tmpMsg;
    Int rc = 0;

    /* new msg is coming, assume that the length of the msg is never greater than the buffer length */
    bzero(recv_msg, RECV_MSG_BUF_LEN);
    recv_len = recv(server_sock_fd, recv_msg, RECV_MSG_BUF_LEN, 0);

    if(recv_len == 0)
    {
        /* The server disconnected */
        LogWrite(ERROR, "%s", "The les station is disconnected!");
        return RC_TLC_LES_DISCONNECT;
    }
    else if(recv_len < 0)
    {
        LogWrite(ERROR, "%s", "The socket to les station is abnormal!");
        return RC_TLC_LINK_ABNORMAL;
    }
    else
    {   
	DEBUG("receive a message, len = %d\n", recv_len);
        tmpMsg.msg_type = ID_CLIENT_MSG;
        tmpMsg.msg_len = recv_len;
	memset(tmpMsg.data, 0, tmpMsg.msg_len); 
	memcpy(tmpMsg.data, recv_msg, recv_len);
	EnQueueMsg(&gSendClientMsgQ, &tmpMsg);
    }

    return rc;
}


static void* HandleClientMain()
{
    struct sockaddr_in server_addr;
    Int conn_try_times;
    Int rc = 0;
    struct timeval tv;
    fd_set client_fd_set;

    DEBUG("The main thread for communicating with dicheng server is running!");
    LogWrite(INFO, "%s", "The main thread for communicating with dicheng server is running!");

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(p_gServerConf->port);
    server_addr.sin_addr.s_addr = inet_addr(p_gServerConf->host);
    bzero(&(server_addr.sin_zero), 8);

    Int server_sock_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(server_sock_fd == -1)
    {
        perror("socket error");
        return NULL;
    }

    conn_try_times = MAX_CONNECT_TRY_TIMES;
    while(0 != conn_try_times)
    {
        DEBUG("Connecting to dicheng server, pls wait ......");
        if(0 == (rc = connect(server_sock_fd, (struct sockaddr *)&server_addr, sizeof(struct sockaddr_in))))
        {
            printf("Connected to dicheng server successfully\n");
            LogWrite(INFO, "%s", "Connected to dicheng server successfully\n");
            break;
        }
        conn_try_times--;
    }

    if(0 != rc)
    {
        DEBUG("Can not connect dicheng server, %s:%d, failed %d times",p_gServerConf->host, p_gServerConf->port, MAX_CONNECT_TRY_TIMES);
        return NULL;
    }
    /* endless loop if server and client work well */
    while(TRUE)
    {
        tv.tv_sec = 20;
        tv.tv_usec = 0;
        FD_ZERO(&client_fd_set);
        FD_SET(server_sock_fd, &client_fd_set);

        /* waiting for data from peer server */
        select(server_sock_fd + 1, &client_fd_set, NULL, NULL, &tv);

        if(FD_ISSET(server_sock_fd, &client_fd_set))
        {
            rc = RecvMsgAfterSelected(server_sock_fd);
        }

        if(RC_TLC_LES_DISCONNECT == rc)
        {
            /* exit the thread because the peer disconnected */
            break;
        }
    }

    DEBUG("Disconnected to dicheng server!\n");
    LogWrite(INFO, "%s", "Disconnected to dicheng server\n");

    return NULL;
}


void SendHeartBeat(Int client_sock_fd)
{
    send(client_sock_fd, HEARTBEAT, 10, 0);
}

Int SliceAreaPCData(BYTE* pHandleMsgBuf, Int len, BYTE* pRemainDataBuf, Int* pRemainCount, Int connfd)
{
    //BYTE* p;
    //Int tmpLen;
    //Int frameLen;
    Int rc;
    //Int sock_id = connfd;   

    if((NULL == pHandleMsgBuf) || (NULL == pRemainDataBuf) || (NULL == pRemainCount) || (0 == len))
    {
        LogWrite(ERROR, "%s", "Input parameter is invalid!");
        return RC_TLC_PARAM_ERR;
    }

    //p = pHandleMsgBuf;
    //tmpLen = len;
    
    rc = RC_TLC_OK;
    
    *pRemainCount = 0;
/*
    while(TRUE)
    {
        if(0 == tmpLen)
        {
            break;
        }
        
        if((tmpLen <= OFFSET_LES_MSG_LEN_FIELD + 1) || (tmpLen < ((Int)(*(p+OFFSET_LES_MSG_LEN_FIELD)) + HEAD_STRING_LEN)))
        {
            *pRemainCount = tmpLen;
            memcpy(pRemainDataBuf, p, tmpLen);
            break;
        }

        if(!IsLesStatCorrectHead(p))
        {
            
            LogWrite(ERROR, "%s", "The head of the data is incorrect!");
            rc = RC_TLC_DATA_ERR;
            break;
        }

        frameLen = (Int)(*(p+OFFSET_LES_MSG_LEN_FIELD));
        ParseLesData(sock_id, p + OFFSET_LES_MSG_ID_FIELD, frameLen);

        p = p + HEAD_STRING_LEN + (Int)(*(p+OFFSET_LES_MSG_LEN_FIELD)); //next
        tmpLen = tmpLen - HEAD_STRING_LEN - frameLen;
        
    }
*/
    return rc;
}



void* HandleOneConnDataMain(void* argv)
{
    BYTE recv_msg[RECV_MSG_BUF_LEN];
    Int recv_len;

    BYTE remainDataBuf[RECV_MSG_BUF_LEN];
    Int remainCount;

    BYTE* pHandleMsgBuf;
    Int handleMsgLen;

    Int connfd;
    connfd = (Int)(*(Int*)argv);
 
    remainCount = 0;
    
    SendHeartBeat(connfd);    

    while(TRUE)
    {
        bzero(recv_msg, RECV_MSG_BUF_LEN);
        recv_len = recv(connfd, recv_msg, RECV_MSG_BUF_LEN, 0);
       
        if(recv_len == 0)
        {
            LogWrite(ERROR, "%s", "disconnected");
            break;
        }
        else if(recv_len < 0)
        {
            DEBUG("AreaPC TCP :errno = %d\n", errno);
            if((errno != EINTR) && (errno != EWOULDBLOCK) && (errno != EAGAIN))
            {
                LogWrite(ERROR, "%s", "The sock to AreaPC is abnormal!");
                DEBUG("AreaPc TCP : errno is not EINTR, EWOULDBLOCK, EAGAIN\n");
                break;
            }
            else
            {
                DEBUG("AreaPc TCP : errno is EINTR, EWOULDBLOCK, EAGAIN\n");
                continue;
            }
        }
        else
        {
             //print recv_msg to check whether package loss
            //PrintHexString(recv_msg, recv_len);

            if(remainCount == 0)
            {
                handleMsgLen = recv_len;
                if(NULL == (pHandleMsgBuf = malloc(handleMsgLen)))
                {
                    LogWrite(ERROR, "%s", "Malloc memeory failed!");
                    break;
                }
                memcpy(pHandleMsgBuf, recv_msg, recv_len);
            }
            else
            {
                handleMsgLen = recv_len + remainCount;
                if(NULL == (pHandleMsgBuf = malloc(handleMsgLen)))
                {
                    LogWrite(ERROR, "%s", "Malloc memeory failed!");
                    break;
                }
                memcpy(pHandleMsgBuf, remainDataBuf, remainCount);
                memcpy(pHandleMsgBuf + remainCount, recv_msg, recv_len);
            }
            SliceAreaPCData(pHandleMsgBuf, handleMsgLen, remainDataBuf, &remainCount, connfd);   
            free(pHandleMsgBuf);
        }
    }
    close(connfd);   
    return NULL;
}


static void* HandleServerMain()
{
    Int server_sock_fd, connfd;
    socklen_t len;
    struct sockaddr_in server_addr, client_addr;
    //UInt lisnum;
    //Int rc;
    //Char loginfo[MAXLEN];

    //lisnum = MAX_CONN_REQ_HANDLE;
     // 开启 socket 监听 
    if ((server_sock_fd = socket(PF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("socket");
        return NULL;
    }
    else
    {
        DEBUG("Create socket successfully!\n");
    }
    //SetNonblocking(server_sock_fd);
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = PF_INET;
    server_addr.sin_port = htons(p_gLesStatConf->port);
    server_addr.sin_addr.s_addr = inet_addr(p_gLesStatConf->host);
    len = sizeof(struct sockaddr);
    if (bind(server_sock_fd, (struct sockaddr *) &server_addr, sizeof(struct sockaddr)) == -1)
    {
        perror("bind");
        return NULL;
    }
    else
    {
        DEBUG("Server IP addr and port bound successfully!\n");
    }

    if (listen(server_sock_fd, 5) == -1)
    {
        perror("listen");
        return NULL;
    }
    else
    {
        DEBUG("Listen service started successfully!\n");
    }
    
    while(TRUE)
    {
        connfd = accept(server_sock_fd, (struct sockaddr*)&client_addr, &len);
        if(connfd < 0)
        {
            perror("accept failed this time");
            DEBUG("sockfd = %d, addr_len = %d", server_sock_fd, len);
            break;
        }
        if(connfd > 0)
        {
            pthread_create(&tmpThreadId, NULL, HandleOneConnDataMain, &connfd);
            pthread_detach(tmpThreadId);
        }
    }

    return NULL;
}

static void* HandleSentClientMsgQMain()
{
	S_MSG tmpMsg;
	
	while(TRUE)
        {
            if(RC_TLC_OK != DeQueueMsg(&gSendClientMsgQ, &tmpMsg))
            {
                continue;
            }

            DEBUG("DeQueueMsg from gSendClientMsgQ successfully");

            Mqtt_publish(CLIENTTOPIC, (char *)tmpMsg.data, tmpMsg.msg_len);
        } 
	return NULL;
}


Int CreateServerThread()
{
    Int rc;

    if(0 != (rc = pthread_create(&g_serverThread, NULL, HandleServerMain, NULL)))
    {
        LogWrite(ERROR, "%s", "Create LES Station Comm thread failed");
    }

    return rc;
}

Int CreateClientThread()
{
    Int rc;
    
    InitMsgQueue(&gSendClientMsgQ, 2000, FALSE, FALSE, "DICHENG");

    if(0 != (rc = pthread_create(&g_clientThread, NULL, HandleClientMain, NULL)))
    {
        LogWrite(ERROR, "%s", "Create client thread failed");
    }

    return rc;
}

Int CreateSendClientMsgQThread()
{
	Int rc;

    if(0 != (rc = pthread_create(&g_sendClientMsgQThread, NULL, HandleSentClientMsgQMain, NULL)))
    {
        LogWrite(ERROR, "%s", "Create client thread failed");
    }

    return rc;
}

















