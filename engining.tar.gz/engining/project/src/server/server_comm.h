#ifndef _SERVER_COMM_H_
#define _SERVER_COMM_H_


#define MAX_CONNECT_TRY_TIMES 10

#define RECV_MSG_BUF_LEN 1024
extern Int tcpSock;
extern Int LoadLesStatConf();
extern Int LoadDataServerConf();

extern Int CreateServerThread();
extern Int CreateClientThread();
extern Int CreateSendClientMsgQThread();

#endif /*_SERVER_COMM_H_ */
