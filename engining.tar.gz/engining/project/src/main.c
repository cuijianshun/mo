#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/time.h>
#include <signal.h>

#include "base_type.h"
#include "log.h"
#include "version.h"
#include "misc_util.h"
#include "server_comm.h"
#include "jp2_comm.h"

static void Print_usage(void)
{
    printf("ProbeManager is a server that communicate to junction probe boards(2g and 4g) or area probe borads so that it can transfer data to User Service and create alert if board does not work.\n");
    printf("Usage: ProbeManager [-v] [-h]\n");
    printf("-v Print version and build time then exit.\n");
    printf("-h Print Help info then exit.\n");
}

static void HelpUser(Int argc, Char *argv[])
{
    if(argc > 2)
    {
        Print_usage();
        return;
    }

    if(2 == argc)
    {
        if(0 == strcmp(argv[1], "-v"))
        {
            printf("Version: %s, Build time: %s, %s\n", VERSION, __DATE__, __TIME__);
            return;
        }

        if(0 == strcmp(argv[1], "-h"))
        {
            Print_usage();
            return;
        }

        Print_usage();
        return;
    }
}

Int InitAfterStart()
{
    Int rc;

    if((rc = GetSelfFullPath()) < 0)
    {
        return rc;
    }

    InitLog();

    LoadLesStatConf();
    LoadDataServerConf();

    return 0;
}

void CleanBeforeExit()
{
    EndLog();    
}

Int main(Int argc, Char *argv[])
{
    if(argc >= 2)
    {
        HelpUser(argc, argv);
        return 1;
    }

    if(InitAfterStart() < 0)
    {
        DEBUG("ProbeManager initialization failed!");
        return 1;
    }


    if(CreateJP2MqttBrokerConn() < 0)
    {
        DEBUG("CreateJP2MqttBrokerConn failed");
    }
    
    CreateServerThread();
    CreateClientThread();
    CreateSendClientMsgQThread();
	
    while(1)
    {
        pause();
    }

    CleanBeforeExit();

    return 0;
}
