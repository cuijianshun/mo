#include <stdio.h>
#include <stdlib.h>
#include <mosquitto.h>
#include <assert.h>
#include <unistd.h>

#include "base_type.h"
#include "log.h"
#include "misc_util.h"
#include "mqtt_settings.h"
#include "mqtt_comm.h"


#define MOS_HEART_BEAT_FREQ   60

struct mosquitto *gMosq = NULL;

void On_mos_connect(struct mosquitto *mosq, void *obj, int result)
{
    S_MOS_USERDATA *ud;
    Int i;

    assert(obj);

    ud = (S_MOS_USERDATA *)obj;

    if(0 == result)
    {
        DEBUG("Connect mqtt broker successfuly.");
        for(i = 0; i < ud->topic_count; i++)
        {
            mosquitto_subscribe(mosq, NULL, ud->pTopics[i].topic, ud->topic_qos);
            DEBUG("topic %d is %s", i, ud->pTopics[i].topic);
        }
    }
    else
    {
        DEBUG("%s", mosquitto_connack_string(result));
    }
}

void On_mos_subscribe(struct mosquitto *mosq, void *obj, int mid, int qos_count, const int *granted_qos)
{
    Int i;

    printf("Subscribed (mid: %d): %d", mid, granted_qos[0]);
    for(i = 1; i < qos_count; i++)
    {
        printf(", %d", granted_qos[i]);
    }
    printf("\n");
}

void On_mos_message(struct mosquitto *mosq, void *obj, const struct mosquitto_message *message)
{
    Int i; 

    S_MOS_USERDATA *ud;

    ud = (S_MOS_USERDATA *)obj;

    for(i = 0; i < ud->topic_count; i++)
    {
        if(0 == strcmp(message->topic, ud->pTopics[i].topic))
        {
            if(NULL != ud->pTopics[i].HandleMsgCallback)
            {
                ud->pTopics[i].HandleMsgCallback(message);
            }
            break;
        }
    }
}

void On_mos_disconnect(struct mosquitto *mosq, void *obj, int result)
{
    /* Stop the heart beat thread */
    mosquitto_loop_stop(mosq, true);

    /* Free the memory we allocated */
    mosquitto_destroy(mosq);     //mosq == gMosq
    gMosq = NULL;


    DEBUG("Mqtt Broker connection shut down, result: %d", result);
}

void On_mos_publish(struct mosquitto *mosq, void *obj, int mid)
{
    //DEBUG("Publish a message: %d", mid);
}

void Mqtt_publish(Char* topic, Char* msg, Int msgLen)
{
    if(NULL != gMosq)
    {
        mosquitto_publish(gMosq, NULL, topic, msgLen, msg, 0, 0);
    }
}

Int CreateMqttBrokerConn(S_MQTT_SETTINGS *pSettings, S_TOPIC_INFO *pTopicInfo, Int topicNum)
{
    S_MOS_USERDATA *pUserData;
    Int keepalive = MOS_HEART_BEAT_FREQ;
    BOOL clean_session = TRUE;
    Int protocol_version = 4;

    Char hostName[MAX_HOST_NAME_LEN];
    Char *pMosClientId;
    Int lenClientId;

    pUserData = (S_MOS_USERDATA *)malloc(sizeof(S_MOS_USERDATA));
    if(NULL == pUserData)
    {
        return RC_TLC_MALLOC_ERR;
    }

    memset(pUserData, 0, sizeof(S_MOS_USERDATA));
    pUserData->eol = TRUE;
    pUserData->quiet = FALSE;
    pUserData->topic_count = topicNum;

    if(topicNum > 0)
    {
        pUserData->pTopics = (S_TOPIC_INFO *)malloc(pUserData->topic_count * sizeof(S_TOPIC_INFO));

        if(NULL == pUserData->pTopics)
        {
            free(pUserData);
            return RC_TLC_MALLOC_ERR;
        }

        memcpy(pUserData->pTopics, pTopicInfo, pUserData->topic_count * sizeof(S_TOPIC_INFO));
    }

    gethostname(hostName, MAX_HOST_NAME_LEN);
    lenClientId = strlen(gCityNo) + 1 + strlen(hostName) + 1 + strlen(pSettings->module) + 1;

    pMosClientId = (Char *)malloc(lenClientId);

    if(NULL == pMosClientId)
    {
        LogWrite(ERROR, "%s", "Allocate memory for mos id before connecting to MOS server failed");
        free(pUserData->pTopics);
        free(pUserData);
        return RC_TLC_MALLOC_ERR;
    }

    snprintf(pMosClientId, lenClientId, "%s-%s-%s", gCityNo, hostName, pSettings->module);

    mosquitto_lib_init();
    gMosq = mosquitto_new(pMosClientId, clean_session, pUserData);

    free(pMosClientId);

    if(NULL != gMosq)
    {
        mosquitto_opts_set(gMosq, MOSQ_OPT_PROTOCOL_VERSION, &protocol_version);
        if(strlen(pSettings->user) > 0)
        {
            mosquitto_username_pw_set(gMosq, pSettings->user, pSettings->passwd);
        }

        mosquitto_connect_callback_set(gMosq, On_mos_connect);
        mosquitto_subscribe_callback_set(gMosq, On_mos_subscribe);
        mosquitto_message_callback_set(gMosq, On_mos_message);
        mosquitto_disconnect_callback_set(gMosq, On_mos_disconnect);
        mosquitto_publish_callback_set(gMosq, On_mos_publish);

        if(MOSQ_ERR_SUCCESS == mosquitto_connect(gMosq, pSettings->host, atoi(pSettings->port), keepalive))
        {
            DEBUG("Connect mqtt broker %s:%s successfully", pSettings->host, pSettings->port);
            mosquitto_loop_start(gMosq);
            return RC_TLC_OK;
        }
        else
        {
            DEBUG("Connect mqtt broker %s:%s failed", pSettings->host, pSettings->port);
            mosquitto_destroy(gMosq);

            return RC_TLC_MQTT_ERR;
        }
    }
    else
    {
        DEBUG("mosquitto_new called failed!");
        return RC_TLC_MQTT_ERR;
    }
}
