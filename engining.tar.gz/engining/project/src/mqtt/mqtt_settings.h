#ifndef _MQTT_SETTINGS_H_
#define _MQTT_SETTINGS_H_

#define MAX_MQTT_SETTING_LEN 64

typedef struct
{
    Char module[MAX_MQTT_SETTING_LEN];
    Char host[MAX_MQTT_SETTING_LEN];
    Char port[MAX_MQTT_SETTING_LEN];
    Char user[MAX_MQTT_SETTING_LEN];
    Char passwd[MAX_MQTT_SETTING_LEN];
} S_MQTT_SETTINGS;

extern Int GetMqttSettings(S_MQTT_SETTINGS *pSettings);
#endif /* _MQTT_SETTINGS_H_ */
