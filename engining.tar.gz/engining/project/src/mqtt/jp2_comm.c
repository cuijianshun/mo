#include <stdio.h>
#include <stdlib.h>
#include <mosquitto.h>

#include "base_type.h"
#include "log.h"
#include "misc_util.h"
#include "mqtt_comm.h"
#include "mqtt_settings.h"
#include "jp2_comm.h"

#define JP2_SUB_TOPIC_NUM 1 

const Char *JP2_MODULE = "probe 2G";

const S_TOPIC_INFO jp2TopicArr[JP2_SUB_TOPIC_NUM] =
    {
        {"testmqtt", HandleTestCallback}
    };

void HandleTestCallback(const struct mosquitto_message *msg)
{
    //S_MSG tmpMsg;

    //tmpMsg.msg_type = ID_PROBE_MSG_MODE;
    //tmpMsg.msg_len = msg->payloadlen;
    //tmpMsg.msg_id = MSG_ID_PROBE_2G_MQTT;
    //memcpy(tmpMsg.data, msg->payload, tmpMsg.msg_len);
    //EnQueueMsg(&gParseProbeMsgQ, &tmpMsg);
}


Int CreateJP2MqttBrokerConn()
{
    S_MQTT_SETTINGS mqttSettings;
    S_TOPIC_INFO jp2TopicArrWithCityno[JP2_SUB_TOPIC_NUM];
    Int i;
    Int rc;

    snprintf(mqttSettings.module, MAX_MQTT_SETTING_LEN, "%s", JP2_MODULE);

    if(RC_TLC_OK != (rc = GetMqttSettings(&mqttSettings)))
    {
        DEBUG("GetMqttSettings failed");
        return rc;
    }

    for(i = 0; i < JP2_SUB_TOPIC_NUM; i++)
    {
        snprintf(jp2TopicArrWithCityno[i].topic, 64, "%s/%s", jp2TopicArr[i].topic, gCityNo);
        jp2TopicArrWithCityno[i].HandleMsgCallback = jp2TopicArr[i].HandleMsgCallback;
    }

    rc = CreateMqttBrokerConn(&mqttSettings, jp2TopicArrWithCityno, JP2_SUB_TOPIC_NUM);
    return rc;
}

