#include <stdio.h>
#include <stdlib.h>

#include "base_type.h"
#include "baseconfig.h"

#include "mqtt_settings.h"

const Char *KEY_MQTT_HOST = "mqtt_host";
const Char *KEY_MQTT_PORT = "mqtt_port";
const Char *KEY_MQTT_USER = "mqtt_user";
const Char *KEY_MQTT_PASSWD = "mqtt_password";

Int GetMqttSettings(S_MQTT_SETTINGS *pSettings)
{
    if(NULL == pSettings)
    {
        return RC_TLC_PARAM_ERR;
    }

    if(0 != GetProfileString(SYS_CONF_FILE, pSettings->module, KEY_MQTT_HOST, pSettings->host))
    {
        return RC_TLC_MQTT_ERR;
    }

    if(0 != GetProfileString(SYS_CONF_FILE, pSettings->module, KEY_MQTT_PORT, pSettings->port))
    {
        return RC_TLC_MQTT_ERR;
    }

    if(0 != GetProfileString(SYS_CONF_FILE, pSettings->module, KEY_MQTT_USER, pSettings->user))
    {
        pSettings->user[0] = '\0';
    }

    if(0 != GetProfileString(SYS_CONF_FILE, pSettings->module, KEY_MQTT_PASSWD, pSettings->passwd))
    {
        pSettings->passwd[0] = '\0';
    }

    return RC_TLC_OK;
}
