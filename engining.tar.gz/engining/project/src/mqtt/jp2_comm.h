#ifndef _JP2_COMM_H_
#define _JP2_COMM_H_

#include "mosquitto.h"

extern void HandleTestCallback(const struct mosquitto_message *msg);
extern Int CreateJP2MqttBrokerConn();
#endif /* _JP2_COMM_H_ */
