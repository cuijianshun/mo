#ifndef _MQTT_COMM_H_
#define _MQTT_COMM_H_

#include "mqtt_settings.h"

#define MAX_TOPIC_NAME_LEN 64

typedef struct {
    Char topic[MAX_TOPIC_NAME_LEN];
    void (*HandleMsgCallback)();
} S_TOPIC_INFO;

typedef struct {
    S_TOPIC_INFO *pTopics;
    Int  topic_count;
    Int  topic_qos;
    Char **filter_outs;
    Int  filter_out_count;
    Char *username;
    Char *password;
    Int  verbose;
    BOOL quiet;
    BOOL no_retain;
    BOOL eol;
} S_MOS_USERDATA;

extern Int CreateMqttBrokerConn(S_MQTT_SETTINGS *pSettings, S_TOPIC_INFO *pTopicInfo, Int topicNum);
extern void Mqtt_publish(Char* topic, Char* msg, Int msgLen);
#endif /* _MQTT_COMM_H_ */
