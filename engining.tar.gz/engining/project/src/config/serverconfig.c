#include <stdlib.h>
#include <stdio.h>

#include <string.h>
#include "base_type.h"
#include "baseconfig.h"
#include "serverconfig.h"

//const char *SYS_CONF_FILE = "./config/system.conf";

const Char *KEY_HOST = "host";
const Char *KEY_IP = "ip";
const Char *KEY_PORT = "port";
const Char *KEY_IMEI = "imei";
const Char *KEY_FEATURE = "feature";
const Char *FEATURE_ON_STR = "on";
const Char *FEATURE_OFF_STR = "off";

void LoadServerConf(const Char *module, S_SERVER_CONF *confServer)
{
    char temp[KEYVALLEN+1];

    memset(confServer, 0, sizeof(S_SERVER_CONF));

    if(0 != GetProfileString(SYS_CONF_FILE, module, KEY_FEATURE, temp))
    {
        confServer->status = FALSE;
    }
    else
    {
        if(0 == strcasecmp(temp, FEATURE_ON_STR))
        {
            confServer->status = TRUE;
        }
        else
        {
            confServer->status = FALSE;
        }
    }

    if(0 != GetProfileString(SYS_CONF_FILE, module, KEY_HOST, confServer->host))
    {
        confServer->host[0] = '\0';
    }

    if(0 != GetProfileString(SYS_CONF_FILE, module, KEY_IMEI, confServer->imei))
    {
        confServer->imei[0] = '\0';
    }

    
    if(0 != GetProfileString(SYS_CONF_FILE, module, KEY_PORT, temp))
    {
        confServer->port = 0;
    }
    else
    {
        confServer->port = atoi(temp);
    }
}

void printfServerConf(S_SERVER_CONF *p)
{
    if(p != NULL)
    {
        printf("feature = %s\n", p->status?"on":"off");
        printf("host = %s\n", p->host);
        printf("ip = %s\n", p->ip);
        printf("port = %d\n", p->port);
    }
}

void LoadSingleSetting(const Char *module, const Char *key, char* pOutString, Int outLen)
{
    char temp[KEYVALLEN+1];
    
    if((NULL == pOutString) ||  (outLen < 1))
    {
        return;
    }
    
    if(0 == GetProfileString(SYS_CONF_FILE, module, key, temp))
    {
        snprintf(pOutString, outLen, "%s", temp);
    }
    else
    {
        pOutString[0] = '\0';
    }
}
