#ifndef _SERVER_CONFIG_H_
#define _SERVER_CONFIG_H_

#define MAX_HOST_NAME_LEN 256
/************** Structure definition ****************/
typedef struct
{
    BOOL status;
    Char host[MAX_HOST_NAME_LEN];
    Char ip[MAX_HOST_NAME_LEN];
    Int port;
    Char imei[16];
} S_SERVER_CONF;

extern void LoadServerConf(const Char *module, S_SERVER_CONF *confServer);
extern void LoadSingleSetting(const Char *module, const Char *key, char* pOutString, Int outLen);
#endif /*_SERVER_CONFIG_H_ */
