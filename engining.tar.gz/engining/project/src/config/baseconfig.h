#ifndef _BASE_CONFIG_H_
#define _BASE_CONFIG_H_

/************** MACRO definitions *******************/

#define KEYVALLEN 256
#define MAX_MODULE_NAME 32
#define MAX_KEY_NAME 32

extern const char *SYS_CONF_FILE;

extern int GetProfileString(const char *profile, const char *ModuleName, const char *KeyName, char *KeyVal);

#endif /* _BASE_CONFIG_H_ */
